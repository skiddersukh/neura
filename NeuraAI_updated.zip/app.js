// ===== NEURA AI — APP.JS =====

const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-6";

const SYSTEM_PROMPT = `Your name is Neura AI. You are an advanced, friendly, and helpful AI assistant created by Sukhvir Singh.

LANGUAGE RULE (very important):
- You ALWAYS respond in English by default.
- You ONLY switch to Hindi (or Hinglish) if the user's message is written in Hindi or Hinglish script. If they write in English, you reply in English — always.
- If the user writes in Hindi (Devanagari or romanized Hindi), you reply in Hindi.
- Never mix languages unless the user does first.

IDENTITY:
- If asked "who made you", "who is your developer", "who created you", or similar: always say "I was created by Sukhvir Singh! 🚀"
- You are currently running on the {MODEL} model.

BEHAVIOR:
- Be helpful, clear, and concise. Use markdown formatting when it adds clarity.
- You are warm, friendly, and professional.`;

// ===== STATE =====
let conversations = [];
try { conversations = JSON.parse(localStorage.getItem('neura_conversations') || '[]'); } catch(e) {}
let currentConvId = null;
let isGenerating = false;
let pendingImageBase64 = null;
let pendingImageType = null;
let pendingImageName = null;
let isRecording = false;
let recognition = null;
let selectedModel = 'Neura Pro';
let rotatingIdx = 0;

// ===== DOM =====
const sidebar         = document.getElementById('sidebar');
const overlay         = document.getElementById('overlay');
const menuBtn         = document.getElementById('menuBtn');
const closeSidebarBtn = document.getElementById('closeSidebar');
const newChatBtn      = document.getElementById('newChatBtn');
const chatHistory     = document.getElementById('chatHistory');
const welcomeScreen   = document.getElementById('welcomeScreen');
const chatArea        = document.getElementById('chatArea');
const inputArea       = document.getElementById('inputArea');
const messagesEl      = document.getElementById('messages');
const userInput       = document.getElementById('userInput');
const sendBtn         = document.getElementById('sendBtn');
const userInputW      = document.getElementById('userInputW');
const sendBtnW        = document.getElementById('sendBtnW');
const modelSelector   = document.getElementById('modelSelector');
const modelDropdown   = document.getElementById('modelDropdown');
const selectedModelEl = document.getElementById('selectedModel');
const attachBtn       = document.getElementById('attachBtn');
const attachBtnW      = document.getElementById('attachBtnW');
const imageBtn        = document.getElementById('imageBtn');
const imageBtnW       = document.getElementById('imageBtnW');
const micBtn          = document.getElementById('micBtn');
const micBtnW         = document.getElementById('micBtnW');
const fileInput       = document.getElementById('fileInput');
const shareBtn        = document.getElementById('shareBtn');
const splashScreen    = document.getElementById('splashScreen');
const imagePreviewBar = document.getElementById('imagePreviewBar');
const imagePreviewImg = document.getElementById('imagePreviewImg');
const imagePreviewName= document.getElementById('imagePreviewName');
const removeImgBtn    = document.getElementById('removeImgBtn');
const imagePreviewBarW = document.getElementById('imagePreviewBarW');
const imagePreviewImgW = document.getElementById('imagePreviewImgW');
const imagePreviewNameW= document.getElementById('imagePreviewNameW');
const removeImgBtnW   = document.getElementById('removeImgBtnW');
const typedGreeting   = document.getElementById('typedGreeting');
const suggestionCards = document.getElementById('suggestionCards');
const rotatingLines   = document.getElementById('rotatingLines');

// ===== INIT =====
function init() {
  setTimeout(() => {
    splashScreen.classList.add('hide');
    setTimeout(() => {
      splashScreen.style.display = 'none';
      document.body.classList.remove('loading');
    }, 600);
    setTimeout(() => typeGreeting(), 400);
    setTimeout(() => {
      document.querySelectorAll('.suggestion-card').forEach(c => c.classList.add('visible'));
    }, 1000);
    setTimeout(() => startRotating(), 1500);
  }, 2700);

  renderHistory();
  setupEventListeners();
}

// ===== TYPING ANIMATION =====
function typeGreeting() {
  const text = "What should we focus on?";
  let i = 0;
  typedGreeting.textContent = '';
  typedGreeting.classList.remove('done');
  typedGreeting.classList.add('typed-text');

  const interval = setInterval(() => {
    typedGreeting.textContent += text[i];
    i++;
    if (i >= text.length) {
      clearInterval(interval);
      setTimeout(() => typedGreeting.classList.add('done'), 800);
    }
  }, 55);
}

// ===== ROTATING LINES =====
function startRotating() {
  const lines = document.querySelectorAll('.r-line');
  if (!lines.length) return;
  setInterval(() => {
    rotatingIdx = (rotatingIdx + 1) % lines.length;
    rotatingLines.style.transform = `translateY(-${rotatingIdx * 32}px)`;
  }, 2500);
}

// ===== EVENTS =====
function setupEventListeners() {
  menuBtn.addEventListener('click', () => toggleSidebar(true));
  closeSidebarBtn?.addEventListener('click', () => toggleSidebar(false));
  overlay.addEventListener('click', () => toggleSidebar(false));
  newChatBtn.addEventListener('click', startNewChat);

  // Chat input
  userInput.addEventListener('input', () => {
    autoResize(userInput);
    sendBtn.disabled = userInput.value.trim() === '' && !pendingImageBase64;
  });
  userInput.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (!sendBtn.disabled && !isGenerating) sendMessage(userInput, false); }
  });
  sendBtn.addEventListener('click', () => { if (!isGenerating) sendMessage(userInput, false); });

  // Welcome input
  userInputW.addEventListener('input', () => {
    autoResize(userInputW);
    sendBtnW.disabled = userInputW.value.trim() === '' && !pendingImageBase64;
  });
  userInputW.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (!sendBtnW.disabled && !isGenerating) sendMessage(userInputW, true); }
  });
  sendBtnW.addEventListener('click', () => { if (!isGenerating) sendMessage(userInputW, true); });

  // Model dropdown
  modelSelector.addEventListener('click', e => { e.stopPropagation(); modelDropdown.classList.toggle('show'); });
  document.querySelectorAll('.model-option').forEach(opt => {
    opt.addEventListener('click', () => {
      selectedModel = opt.dataset.model;
      selectedModelEl.textContent = selectedModel;
      document.querySelectorAll('.model-option').forEach(o => { o.classList.remove('active'); o.querySelector('.check-icon').style.opacity='0'; });
      opt.classList.add('active'); opt.querySelector('.check-icon').style.opacity='1';
      modelDropdown.classList.remove('show');
      showToast(`${selectedModel} selected ✓`);
    });
  });
  document.addEventListener('click', () => modelDropdown.classList.remove('show'));

  // Suggestion cards
  document.querySelectorAll('.suggestion-card').forEach(card => {
    card.addEventListener('click', () => {
      userInputW.value = card.dataset.prompt;
      autoResize(userInputW);
      sendBtnW.disabled = false;
      sendMessage(userInputW, true);
    });
  });

  // File inputs
  attachBtn?.addEventListener('click', () => { fileInput._target='chat'; fileInput.click(); });
  attachBtnW?.addEventListener('click', () => { fileInput._target='welcome'; fileInput.click(); });
  imageBtn?.addEventListener('click', () => { fileInput._target='chat'; fileInput.click(); });
  imageBtnW?.addEventListener('click', () => { fileInput._target='welcome'; fileInput.click(); });

  fileInput.addEventListener('change', e => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      pendingImageBase64 = reader.result.split(',')[1];
      pendingImageType = file.type;
      pendingImageName = file.name;
      if (fileInput._target === 'welcome') {
        imagePreviewImgW.src = reader.result;
        imagePreviewNameW.textContent = file.name;
        imagePreviewBarW.style.display = 'flex';
        sendBtnW.disabled = false;
      } else {
        imagePreviewImg.src = reader.result;
        imagePreviewName.textContent = file.name;
        imagePreviewBar.style.display = 'flex';
        sendBtn.disabled = false;
      }
    };
    reader.readAsDataURL(file);
    fileInput.value = '';
  });

  removeImgBtn?.addEventListener('click', clearPendingImage);
  removeImgBtnW?.addEventListener('click', clearPendingImage);
  micBtn?.addEventListener('click', () => toggleMic(micBtn));
  micBtnW?.addEventListener('click', () => toggleMic(micBtnW));
  shareBtn?.addEventListener('click', () => { navigator.clipboard.writeText(location.href).then(() => showToast('Link copied! 🔗')); });
}

// ===== SIDEBAR =====
function toggleSidebar(open) {
  sidebar.classList.toggle('open', open);
  overlay.classList.toggle('show', open);
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 200) + 'px';
}

function clearPendingImage() {
  pendingImageBase64 = null; pendingImageType = null; pendingImageName = null;
  imagePreviewBar.style.display = 'none'; imagePreviewImg.src = '';
  imagePreviewBarW.style.display = 'none'; imagePreviewImgW.src = '';
  sendBtn.disabled = userInput.value.trim() === '';
  sendBtnW.disabled = userInputW.value.trim() === '';
}

// ===== NEW CHAT =====
function startNewChat() {
  currentConvId = null;
  messagesEl.innerHTML = '';
  welcomeScreen.style.display = 'flex';
  chatArea.style.display = 'none';
  inputArea.style.display = 'none';
  userInput.value = ''; userInputW.value = '';
  autoResize(userInput); autoResize(userInputW);
  sendBtn.disabled = true; sendBtnW.disabled = true;
  clearPendingImage();
  document.querySelectorAll('.history-item').forEach(i => i.classList.remove('active'));
  toggleSidebar(false);

  // Re-animate
  typedGreeting.classList.remove('done');
  typedGreeting.classList.remove('typed-text');
  typedGreeting.textContent = '';
  setTimeout(typeGreeting, 300);
  document.querySelectorAll('.suggestion-card').forEach(c => {
    c.classList.remove('visible'); void c.offsetWidth;
    setTimeout(() => c.classList.add('visible'), 100);
  });
}

// ===== CONVERSATION =====
function getOrCreateConversation() {
  if (currentConvId) return conversations.find(c => c.id === currentConvId);
  const conv = { id: Date.now().toString(), title: 'New Chat', messages: [], model: selectedModel, created: Date.now() };
  conversations.unshift(conv);
  currentConvId = conv.id;
  save(); renderHistory();
  return conv;
}

function save() {
  try { localStorage.setItem('neura_conversations', JSON.stringify(conversations)); } catch(e) {}
}

function renderHistory() {
  chatHistory.innerHTML = '';
  const items = conversations.slice(0, 20);
  if (!items.length) {
    chatHistory.innerHTML = '<p style="font-size:13px;color:var(--text-muted);padding:8px 16px">No previous chats</p>';
    return;
  }
  items.forEach((conv, idx) => {
    const item = document.createElement('div');
    item.className = 'history-item' + (conv.id === currentConvId ? ' active' : '');
    item.style.animationDelay = (idx * 0.05) + 's';
    item.innerHTML = `<span class="material-icons-round">chat_bubble_outline</span>${escHtml(conv.title)}`;
    item.addEventListener('click', () => loadConversation(conv.id));
    chatHistory.appendChild(item);
  });
}

function loadConversation(id) {
  const conv = conversations.find(c => c.id === id);
  if (!conv) return;
  currentConvId = id;
  messagesEl.innerHTML = '';
  welcomeScreen.style.display = 'none';
  chatArea.style.display = 'flex';
  inputArea.style.display = 'block';

  conv.messages.forEach(msg => {
    if (msg.role === 'user') {
      const text = typeof msg.content === 'string' ? msg.content : (msg.content.find(c=>c.type==='text')?.text || '');
      addUserMessage(text, false);
    } else {
      addAssistantMessage(msg.content, false);
    }
  });

  scrollBottom(); renderHistory(); toggleSidebar(false);
}

// ===== SEND =====
async function sendMessage(inputEl, isWelcome) {
  const text = inputEl.value.trim();
  if ((!text && !pendingImageBase64) || isGenerating) return;

  isGenerating = true;
  sendBtn.disabled = true;
  sendBtnW.disabled = true;

  const conv = getOrCreateConversation();

  // Switch to chat view
  welcomeScreen.style.display = 'none';
  chatArea.style.display = 'flex';
  inputArea.style.display = 'block';

  let userContent;
  if (pendingImageBase64) {
    userContent = [
      { type: 'image', source: { type: 'base64', media_type: pendingImageType, data: pendingImageBase64 } },
      { type: 'text', text: text || 'Tell me about this image.' }
    ];
  } else {
    userContent = text;
  }

  addUserMessage(text, true, pendingImageBase64, pendingImageType);
  inputEl.value = ''; autoResize(inputEl);
  userInput.value = ''; autoResize(userInput);
  clearPendingImage();

  conv.messages.push({ role: 'user', content: userContent });
  if (conv.title === 'New Chat' && text) {
    conv.title = text.slice(0, 45) + (text.length > 45 ? '…' : '');
    renderHistory();
  }
  save();

  const typingEl = addTypingIndicator();
  scrollBottom();

  try {
    const apiMessages = conv.messages.map(m => ({ role: m.role, content: m.content }));
    const res = await fetch(ANTHROPIC_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1000,
        system: SYSTEM_PROMPT.replace('{MODEL}', selectedModel),
        messages: apiMessages
      })
    });

    const data = await res.json();
    typingEl.remove();

    if (data.error) {
      const err = `**Error:** ${data.error.message}`;
      addAssistantMessage(err, true);
      conv.messages.push({ role: 'assistant', content: err });
    } else {
      const full = data.content?.map(c => c.text || '').join('') || 'No response received.';
      addAssistantMessage(full, true);
      conv.messages.push({ role: 'assistant', content: full });
    }
    save();
  } catch(err) {
    typingEl.remove();
    const msg = `**Network Error:** ${err.message}\n\nMake sure you've added your API key in app.js`;
    addAssistantMessage(msg, true);
  }

  isGenerating = false;
  sendBtn.disabled = userInput.value.trim() === '';
  sendBtnW.disabled = userInputW.value.trim() === '';
  scrollBottom();
}

// ===== ADD MESSAGES =====
function addUserMessage(text, animate=true, imgB64=null, imgType=null) {
  const div = document.createElement('div');
  div.className = 'message user';
  if (!animate) div.style.animation = 'none';
  const imgHtml = imgB64 ? `<img class="msg-image" src="data:${imgType};base64,${imgB64}" alt="Uploaded"/>` : '';
  div.innerHTML = `<div class="msg-content">${imgHtml}${text ? escHtml(text) : ''}</div>`;
  messagesEl.appendChild(div);
}

function addAssistantMessage(text, animate=true) {
  const uid = Date.now();
  const div = document.createElement('div');
  div.className = 'message assistant';
  if (!animate) div.style.animation = 'none';

  div.innerHTML = `
    <div class="msg-avatar">
      <svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="mg${uid}" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#4285f4"/>
            <stop offset="50%" stop-color="#a855f7"/>
            <stop offset="100%" stop-color="#ec4899"/>
          </linearGradient>
        </defs>
        <path d="M60 4 C60 4 66 46 90 60 C66 74 60 116 60 116 C60 116 54 74 30 60 C54 46 60 4 60 4Z" fill="url(#mg${uid})"/>
        <path d="M60 4 C60 4 66 46 90 60 C66 74 60 116 60 116 C60 116 54 74 30 60 C54 46 60 4 60 4Z" fill="url(#mg${uid})" style="opacity:0.5;transform:rotate(90deg);transform-origin:60px 60px"/>
      </svg>
    </div>
    <div class="msg-body">
      <div class="msg-text">${mdToHtml(text)}</div>
      <div class="msg-actions">
        <button class="msg-action-btn" onclick="copyMsg(this)" title="Copy"><span class="material-icons-round">content_copy</span></button>
        <button class="msg-action-btn" onclick="thumbUp(this)" title="Good response"><span class="material-icons-round">thumb_up</span></button>
        <button class="msg-action-btn" onclick="thumbDown(this)" title="Bad response"><span class="material-icons-round">thumb_down</span></button>
        <button class="msg-action-btn" onclick="shareMsg(this)" title="Share"><span class="material-icons-round">ios_share</span></button>
      </div>
    </div>`;

  messagesEl.appendChild(div);

  div.querySelectorAll('pre').forEach(pre => {
    const btn = document.createElement('button');
    btn.className = 'copy-code-btn';
    btn.innerHTML = '<span class="material-icons-round" style="font-size:14px">content_copy</span> Copy';
    btn.onclick = () => {
      const code = pre.querySelector('code')?.textContent || pre.textContent;
      navigator.clipboard.writeText(code).then(() => {
        btn.innerHTML = '<span class="material-icons-round" style="font-size:14px;color:#34a853">check</span> Copied!';
        setTimeout(() => { btn.innerHTML = '<span class="material-icons-round" style="font-size:14px">content_copy</span> Copy'; }, 2000);
      });
    };
    pre.style.position = 'relative';
    pre.appendChild(btn);
  });

  return div;
}

function addTypingIndicator() {
  const uid = Date.now();
  const div = document.createElement('div');
  div.className = 'message assistant';
  div.innerHTML = `
    <div class="msg-avatar">
      <svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
        <defs><linearGradient id="tg${uid}" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#4285f4"/><stop offset="100%" stop-color="#a855f7"/>
        </linearGradient></defs>
        <path d="M60 4 C60 4 66 46 90 60 C66 74 60 116 60 116 C60 116 54 74 30 60 C54 46 60 4 60 4Z" fill="url(#tg${uid})"/>
        <path d="M60 4 C60 4 66 46 90 60 C66 74 60 116 60 116 C60 116 54 74 30 60 C54 46 60 4 60 4Z" fill="url(#tg${uid})" style="opacity:0.5;transform:rotate(90deg);transform-origin:60px 60px"/>
      </svg>
    </div>
    <div class="msg-body"><div class="typing-dots"><span></span><span></span><span></span></div></div>`;
  messagesEl.appendChild(div);
  return div;
}

// ===== MARKDOWN =====
function mdToHtml(t) {
  let h = t;
  h = h.replace(/```(\w+)?\n?([\s\S]*?)```/g, (_,lang,code) => `<pre><code class="lang-${lang||'text'}">${escHtml(code.trim())}</code></pre>`);
  h = h.replace(/`([^`\n]+)`/g, '<code>$1</code>');
  h = h.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  h = h.replace(/\*(.+?)\*/g, '<em>$1</em>');
  h = h.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  h = h.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  h = h.replace(/^# (.+)$/gm, '<h1>$1</h1>');
  h = h.replace(/^[*\-] (.+)$/gm, '<li>$1</li>');
  h = h.replace(/(<li>[\s\S]+?<\/li>)/g, '<ul>$1</ul>');
  h = h.split(/\n\n+/).map(p => {
    p = p.trim();
    if (!p || p.startsWith('<h') || p.startsWith('<ul') || p.startsWith('<ol') || p.startsWith('<pre') || p.startsWith('<li')) return p;
    return `<p>${p.replace(/\n/g,'<br>')}</p>`;
  }).join('\n');
  return h;
}

function escHtml(s) { const d=document.createElement('div'); d.appendChild(document.createTextNode(s||'')); return d.innerHTML; }
function scrollBottom() { requestAnimationFrame(() => { chatArea.scrollTop = chatArea.scrollHeight; }); }
function showToast(msg) {
  let t = document.querySelector('.toast');
  if (!t) { t = document.createElement('div'); t.className='toast'; document.body.appendChild(t); }
  t.textContent = msg; t.classList.add('show');
  clearTimeout(t._to); t._to = setTimeout(() => t.classList.remove('show'), 2500);
}

function copyMsg(btn) { navigator.clipboard.writeText(btn.closest('.msg-body').querySelector('.msg-text').innerText).then(() => showToast('Copied! ✓')); }
function thumbUp(btn) { btn.querySelector('.material-icons-round').style.color='var(--accent-blue)'; showToast('Thanks for the feedback! 👍'); }
function thumbDown(btn) { btn.querySelector('.material-icons-round').style.color='var(--accent-red)'; showToast('Feedback noted! 🙏'); }
function shareMsg(btn) {
  const text = btn.closest('.msg-body').querySelector('.msg-text').innerText;
  if (navigator.share) navigator.share({ title:'Neura AI', text });
  else navigator.clipboard.writeText(text).then(() => showToast('Copied for sharing! 🔗'));
}

// ===== MIC =====
function toggleMic(btn) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { showToast('Speech not supported in this browser.'); return; }
  if (isRecording) { recognition?.stop(); isRecording=false; btn.classList.remove('recording'); return; }
  recognition = new SR();
  recognition.lang = 'en-IN';
  recognition.interimResults = false;
  recognition.onstart = () => { isRecording=true; btn.classList.add('recording'); showToast('Listening... 🎤'); };
  recognition.onresult = e => {
    const t = e.results[0][0].transcript;
    const active = document.getElementById('welcomeScreen').style.display !== 'none' ? userInputW : userInput;
    active.value += (active.value ? ' ' : '') + t;
    autoResize(active);
    (active === userInputW ? sendBtnW : sendBtn).disabled = false;
  };
  recognition.onend = () => { isRecording=false; btn.classList.remove('recording'); };
  recognition.onerror = e => { isRecording=false; btn.classList.remove('recording'); showToast('Mic error: '+e.error); };
  recognition.start();
}

init();
